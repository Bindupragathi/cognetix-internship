# Sales Data Analysis

## Objective
Analyze sales data to identify top-performing products, regional revenue, category performance, and sales trends.

## Tools Used
- Python
- Pandas
- NumPy
- Matplotlib
- Seaborn
- Jupyter Notebook

## Deliverables
- Cleaned dataset
- 5–7 professional visualizations
- Business insights

## How to Run
1. Install dependencies:
   pip install pandas numpy matplotlib seaborn jupyter
2. Place `sales_data.csv` in this folder
3. Run:
   jupyter notebook
4. Open `analysis.ipynb` and run all cells
