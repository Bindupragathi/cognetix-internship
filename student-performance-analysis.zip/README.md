
# Student Performance Analysis

## Objective
Analyze student academic performance to compute averages, identify top performers, and visualize trends.

## Tools Used
Python, Pandas, NumPy, Matplotlib, Seaborn

## Dataset
https://www.kaggle.com/datasets/spscientist/students-performance-in-exams
